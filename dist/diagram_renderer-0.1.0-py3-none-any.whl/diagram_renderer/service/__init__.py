"""Reusable stateful services."""
