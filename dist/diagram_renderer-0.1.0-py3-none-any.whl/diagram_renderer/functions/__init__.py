"""Reusable pure helper functions."""
